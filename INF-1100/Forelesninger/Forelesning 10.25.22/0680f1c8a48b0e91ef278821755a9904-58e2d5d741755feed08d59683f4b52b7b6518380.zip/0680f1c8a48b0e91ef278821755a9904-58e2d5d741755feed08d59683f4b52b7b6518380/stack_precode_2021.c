#include <stdio.h>

char STACK[128];              // holds stack data
int top = 0;                  // points to top of stack

void push(char ch) {          // implement me
}

char pop() {                  // implement me
}

int main() {
	push(1); push(2); push(3);

	// should print 3 2 1 
	printf("%d %d %d\n", pop(), pop(), pop());
}