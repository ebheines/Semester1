#include <stdio.h>

char STACK[128];              
int top = 0;                  

void push(char ch) {
	STACK[top] = ch;          
	top = top + 1;            
}

char pop() {
	top = top - 1;            
	return STACK[top];        
}

/*
	The function below should be
	
	void subtract() {
		/// something
	}
	
	No arguments!
*/
void subtract(char a, char b) {
	push(a - b);            // push return val on stack
}

int main() {
	// something needs to change here also
	subtract(6, 5);
	printf("6 - 5 = %d\n", pop());
}