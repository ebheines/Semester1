#include <stdlib.h>
#include <stdio.h>
#include <SDL.h>
#include "triangle.h"
#include "drawline.h"
#include "fill_triangle.h"

#define TRIANGLE_PENCOLOR   0xBBBB0000


/*
 * Fill the triangle on the surface with the triangle's color
 */
void b_fill_triangle(SDL_Surface *surface, triangle_t *triangle)
{
    // TODO: Insert code that fills the triangle with the color specified in triangle->fillcolor.
    // Hint: Draw the triangle with color TRIANGLE_PENCOLOR (this color can not
    // occur in e.g. the teapot or the example triangles).  Thus, if your 
    // approach to filling the triangle relies on looking for the edges of
    // the triangle on the surface (via the GetPixel function), you will find those
    // edges even if the triangle overlaps with a triangle that has already
    // been drawn on the surface.

    int y;
    int x;
    int xmax;

    //triple nested for-loops to go from ymin - ymax, xmin - xmax and at last xmax - xmin
    for(y = triangle->rect.y; y <= triangle->rect.h; y++) {
        for(x = triangle->rect.x; x <= triangle->rect.w; x++) 
            //if test to break the for-loop if the surface is = TRIANGLE_PENCOLOR
            if (get_pixel(surface, x, y) == TRIANGLE_PENCOLOR)
            {
                break;
            }
        
            for(xmax = triangle->rect.w; xmax > x; xmax--) 
            //if test to break the for-loop if the surface is = TRIANGLE_PENCOLOR
            if (get_pixel(surface, xmax, y) == TRIANGLE_PENCOLOR)
            {
                break;
            }
            //draw_line trough all of the triangles
            draw_line(surface, x, y, xmax, y, triangle->fillcolor);
        }

}

/*
 * Draw a filled triangle on the given surface
 */
void b_draw_triangle(SDL_Surface *surface, triangle_t *triangle)
{
    int isOK;
    
    /* Translate. */
    translate_triangle(triangle);
    
    /* Determine bounding box */
    calculate_triangle_bounding_box(triangle);

    /* Sanity check that triangle is within surface boundaries. */
    isOK = sanity_check_triangle(surface, triangle);
    if (!isOK) {
        print_triangle(triangle, "Triangle outside surface boundaries");
        return;
    }
    /* 
     * TODO: Insert calls to draw_line to draw the triangle.
     * Remember to use the on-surface coordinat
    /* es (triangle->sx1, etc.)triangle -> fillcolor
    */

    // draw_line(surface, triangle->rect.x, triangle->rect.y, triangle->rect.w, triangle->rect.y, TRIANGLE_PENCOLOR);
    // draw_line(surface, triangle->rect.x, triangle->rect.y, triangle->rect.x, triangle->rect.h, TRIANGLE_PENCOLOR);
    // draw_line(surface, triangle->rect.x, triangle->rect.h, triangle->rect.w, triangle->rect.h, TRIANGLE_PENCOLOR);
    // draw_line(surface, triangle->rect.w, triangle->rect.y, triangle->rect.w, triangle->rect.h, TRIANGLE_PENCOLOR);

    draw_line(surface, triangle->sx1, triangle->sy1, triangle->sx2, triangle->sy2, TRIANGLE_PENCOLOR);
    draw_line(surface, triangle->sx2, triangle->sy2, triangle->sx3, triangle->sy3, TRIANGLE_PENCOLOR);
    draw_line(surface, triangle->sx3, triangle->sy3, triangle->sx1, triangle->sy1, TRIANGLE_PENCOLOR);


    /* Fill triangle */
    b_fill_triangle(surface, triangle);
}
