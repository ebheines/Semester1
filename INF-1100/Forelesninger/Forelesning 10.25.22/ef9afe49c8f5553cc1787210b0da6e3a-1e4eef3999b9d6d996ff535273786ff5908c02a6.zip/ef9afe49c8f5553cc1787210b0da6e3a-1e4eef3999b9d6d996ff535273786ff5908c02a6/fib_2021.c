#include <stdio.h>

// implement me:
int fib(int n) {

}

int main() {
	printf("after 12 months we have %d rabbits\n", fib(12));
}