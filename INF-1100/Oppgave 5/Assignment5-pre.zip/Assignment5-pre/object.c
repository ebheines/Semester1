#include <stdlib.h>
#include <stdio.h>
#include <SDL.h>
#include "drawline.h"
#include "triangle.h"
#include "object.h"


/*
 * Return a newly created object based on the arguments provided.
 */
object_t *create_object(SDL_Surface *surface, triangle_t *model, int numtriangles)
{
    /* Implement me */
}

/*
 * Destroy the object, freeing the memory.
 */
void destroy_object(object_t *object)
{
    /* Implement me */
}

/*
 * Draw the object on its surface.
 */
void draw_object(object_t *object)
{
    /* Implement me */
} 
